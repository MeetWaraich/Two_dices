package com.example.twodices;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ImageView upperDiceImage = findViewById(R.id.upperDice);
        final ImageView lowerDiceImage = findViewById(R.id.lowerDice);
        final TextView result = findViewById(R.id.result);

        findViewById(R.id.play).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                int randomNumber1 = random.nextInt(6-1)+1;
                int randomNumber2 = random.nextInt(6-1)+1;

                String upperDice = "Dice"+randomNumber1;

                switch (randomNumber1){
                    case 1:
                        upperDiceImage.setImageResource(R.drawable.dice1);
                        break;
                    case 2:
                        upperDiceImage.setImageResource(R.drawable.dice2);
                        break;
                    case 3:
                        upperDiceImage.setImageResource(R.drawable.dice3);
                        break;
                    case 4:
                        upperDiceImage.setImageResource(R.drawable.dice4);
                        break;
                    case 5:
                        upperDiceImage.setImageResource(R.drawable.dice5);
                        break;
                    case 6:
                        upperDiceImage.setImageResource(R.drawable.dice6);
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + randomNumber1);
                }

                switch (randomNumber2){
                    case 1:
                        lowerDiceImage.setImageResource(R.drawable.dice1);
                        break;
                    case 2:
                        lowerDiceImage.setImageResource(R.drawable.dice2);
                        break;
                    case 3:
                        lowerDiceImage.setImageResource(R.drawable.dice3);
                        break;
                    case 4:
                        lowerDiceImage.setImageResource(R.drawable.dice4);
                        break;
                    case 5:
                        lowerDiceImage.setImageResource(R.drawable.dice5);
                        break;
                    case 6:
                        lowerDiceImage.setImageResource(R.drawable.dice6);
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + randomNumber2);
                }

                int res = 0;

                if(randomNumber1-randomNumber2 < 0){
                     res = randomNumber2-randomNumber1;
                }
                else{
                     res = randomNumber1-randomNumber2;
                }


                result.setText(String.valueOf(res));











            }
        });

    }
}